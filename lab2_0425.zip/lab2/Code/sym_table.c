#include "sym_table.h"
#include "assert.h"
//sym,func and struct table
St_Type *struct_table[0x3fff];
Sym_Type *symbol_table[0x3fff];
F_Type *function_table[0x3fff];

int name_count = 0;

//insert and find
F_Type *find_Func(char *name)
{
    int sum = 0;
    for (int i = 0; name[i] != '\0'; i++)
    {
        sum += name[i];
    }
    for (F_Type *p = function_table[sum % 0x3fff]; p != NULL; p = p->next)
    {
        if ((!strcmp(name, p->name)))
            return p;
    }
    return NULL;
}
Sym_Type *find_Sym(char *name)
{
    int sum = 0;
    for (int i = 0; name[i] != '\0'; i++)
    {
        sum += name[i];
    }
    for (Sym_Type *p = symbol_table[sum % 0x3fff]; p != NULL; p = p->next)
    {
        if (!strcmp(name, p->name))
            return p;
    }
    return NULL;
}
St_Type *find_Stru(char *name)
{
    int sum = 0;
    for (int i = 0; name[i] != '\0'; i++)
    {
        sum += name[i];
    }
    for (St_Type *p = struct_table[sum % 0x3fff]; p != NULL; p = p->next)
    {
        if (!strcmp(name, p->type->u.structure->name))
            return p;
    }
    return NULL;
}
void insert_Func(char *name, int sort, int dim, Type *r_type, struct t_paralist *para_list, int line)
{
    int sum = 0;
    for (int i = 0; name[i] != '\0'; i++)
    {
        sum += name[i];
    }
    F_Type *p = (F_Type *)malloc(sizeof(F_Type));
    p->next = function_table[sum % 0x3fff];
    function_table[sum % 0x3fff] = p;
    p->dim = dim;
    p->name = name;
    p->para_list = para_list;
    p->r_type = r_type;
    p->sort = sort;
    p->line = line;
}
bool type_check(Type *a, Type *b)
{
    if (a == NULL || b == NULL)
        return false;
    if (a->kind != b->kind)
        return false;
    if (a->kind == BASIC)
    {
        if (a->u.basic != b->u.basic)
            return false;
    }
    else if (a->kind == ARRAY)
    {
        return type_check(a->u.array.elem, b->u.array.elem);
    }
    else if (a->kind == STRUCTURE)
    {
        if (!strcmp(a->u.structure->name, b->u.structure->name))
            return false;
    }
    return true;
}
bool check_func(int dim, Type *r_type, struct t_paralist *para_list, F_Type *p)
{
    if (p->dim != dim)
        return false;
    if (!type_check(r_type, p->r_type))
        return false;
    for (struct t_paralist *i = para_list, *j = p->para_list; i != NULL; i = i->next, j = j->next)
    {
        if (!type_check(i->para_type, j->para_type))
            return false;
    }
    return true;
}
void decfunc(F_Type *p)
{
    p->sort = 1;
}
void insert_Struc(Type *type, char *name)
{
    int sum = 0;
    for (int i = 0; name[i] != '\0'; i++)
    {
        sum += name[i];
    }
    St_Type *p = (St_Type *)malloc(sizeof(St_Type));
    p->type = type;
    p->next = struct_table[sum % 0x3fff];
    struct_table[sum % 0x3fff] = p;
}
void insert_Sym(Type *type, char *name)
{
    int sum = 0;
    for (int i = 0; name[i] != '\0'; i++)
    {
        sum += name[i];
    }
    Sym_Type *p = (Sym_Type *)malloc(sizeof(Sym_Type));
    p->name = name;
    p->type = type;
    p->next = symbol_table[sum % 0x3fff];
    symbol_table[sum % 0x3fff] = p;
}
void Program(Node *root)
{
    if (!root || root->vacuum) return;
    //printf("Program\n");
    ExtDefList(root->child);
}
void ExtDefList(Node *root){
    if (!root || root->vacuum) return;
    //printf("ExtDefList\n");
    Node* def = root->child;
    ExtDef(def);
    ExtDefList(def->next);
}
void ExtDef(Node *root){
    if (!root || root->vacuum) return;
    //printf("ExtDef\n");
    Type* type = Specifier(root->child);
    Node* next = root->child->next;
    assert(next && !next->vacuum);
    //ExtDef -> Specifier SEMI
    if (!strcmp(next->name,"SEMI")){
        if (type->kind == STRUCTURE){
            //TODO with anonymous struct def
            name_count++;
        }
        //basic or array type: skip
        return;
    }
    if (!strcmp(next->name,"ExtDecList")){
        ExtDecList(next,type);
        return;
    }
    if (!strcmp(next->name,"FunDec")){
        FunDec(next,type);
    }

}
void ExtDecList(Node *root, Type *type){
    if (!root || root->vacuum) return;
    //printf("ExtDecList\n");
    Node* var = root->child;
    VarDec(var,type);

    if (!var->next || var->next->vacuum) return;
    //ExtDecList -> VarDec COMMMA ExtDecList
    ExtDecList(var->next->next,type);
}

//Specifiers
Type *Specifier(Node *root){
    if (!root || root->vacuum) return NULL;
    //printf("Specifier\n");

    Node* typeNode = root->child;

    //Specifier -> TYPE
    if (!strcmp(typeNode->name,"TYPE")){
        Type* type = (Type*)malloc(sizeof(Type));
        type->kind = BASIC;
        if (!strcmp(typeNode->val,"int")){
            type->u.basic = 0;//??
        }else{  //typeNode->val=="float"
            type->u.basic = 1;
        }
    }else{  //Specifier -> StructSpecifier
        return StructSpecifier(typeNode);
    }

}
//TODO
Type *StructSpecifier(Node *root){
    return NULL;
}

char *OptTag(Node *root){
    return NULL;
}
char *Tag(Node *root){
    return NULL;
}

//Declarators
Type *VarDec(Node *root, Type *type){
    if (!root || root->vacuum) return NULL;
    //printf("VarDec\n");
    Node* first = root->child;
    //VarDec -> ID
    if (!strcmp(first->name,"ID")){
        if (find_Sym(first->val) || find_Stru(first->val)){
            print_error(3, first);
        }else{
            printf("Insert_Sym:%s\n",first->val);
            insert_Sym(type, first->val);
        }

    }else{  //first->name == "VarDec"
    //VarDec -> VarDec LB INT RB	
        Node* sizeNode = first->next->next;
        assert(!strcmp(sizeNode->name,"INT"));
        int size = atoi(sizeNode->val);
        Type* type1 = (Type*)malloc(sizeof(Type));
        type1->kind = ARRAY;
        type1->u.array.elem = type;
        type1->u.array.size = size;
        VarDec(first,type1);
    }
    return type;
}
//TODO
void FunDec(Node *root, Type *r_type){

}
Type *ParamDec(Node *root){
    return NULL;
}
struct t_paralist *VarList(Node *root){
    return NULL;
}

//Statements
void CompSt(Node *root, Type *r_type){}
void StmtList(Node *root, Type *r_type){}
void Stmt(Node *root, Type *r_type){}

//Local Definitions
void DefList(Node *root){}
void Def(Node *root){}
void DecList(Node *root, Type *type){}
void Dec(Node *root, Type *type){}

//Expressions
Type *Exp(Node *root){return NULL;} //every expression has a type
void Args(Node *root){} //parameter_list, check each parameter's type

void print_error(int errorNo, Node* node){
    printf("ERROR TYPE %d at line %d: ", errorNo, node->line);
    switch (errorNo)
    {
    case 3:
        printf("Redefined variable \"%s\".\n", node->val);
        break;
    
    default:
        break;
    }
    
}
