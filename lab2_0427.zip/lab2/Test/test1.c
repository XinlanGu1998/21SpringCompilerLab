int main()
{
    int i = 0;
    j = i + 1;
}
