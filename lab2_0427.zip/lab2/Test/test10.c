int main()
{
    int i;
    i[0];
}