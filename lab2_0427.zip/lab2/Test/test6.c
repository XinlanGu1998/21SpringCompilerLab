int main()
{
    int i;
    10 = i;
}