int main()
{
    int i, j;
    int i;
}