int main()
{
    struct Position pos;
}