struct Position
{
    float x, y;
    int x;
};

int main()
{
}