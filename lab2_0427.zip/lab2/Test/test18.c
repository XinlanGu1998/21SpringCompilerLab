int func(int a);

int func(int a)
{
    return 1;
}

int main()
{
}