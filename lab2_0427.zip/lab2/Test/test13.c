struct Position
{
    float x, y;
};

int main()
{
    int i;
    i.x;
}