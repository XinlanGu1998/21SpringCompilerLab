int main()
{
    float j = 1.7;
    return j;
}