int main()
{
    float j;
    10 + j;
}