int func(int i)
{
    return i;
}

int func()
{
    return 0;
}

int main()
{
}