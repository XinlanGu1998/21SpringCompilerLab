int main()
{
    int i;
    i = 3.7;
}