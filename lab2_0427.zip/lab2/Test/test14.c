struct Position
{
    float x, y, z, w;
    float a, b, c;
};

int main()
{
    struct Position p;
    if (p.n == 3.7)
        return 0;
    
}