int main()
{
	int i = 0;
	inc(i);
}