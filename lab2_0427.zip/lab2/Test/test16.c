struct Position
{
    float x;
};

struct Position
{
    int y;
};

int main()
{
}