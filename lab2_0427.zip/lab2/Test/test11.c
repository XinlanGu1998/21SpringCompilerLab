int main()
{
    int i;
    i(10);
}